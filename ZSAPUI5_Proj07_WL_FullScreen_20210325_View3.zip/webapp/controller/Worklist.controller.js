sap.ui.define([
		"zsapui5proj07wlfullscreen/controller/BaseController",
		"sap/ui/model/json/JSONModel",
		"sap/ui/core/routing/History",
		"zsapui5proj07wlfullscreen/model/formatter",
		"sap/ui/model/Filter",
		"sap/ui/model/FilterOperator",
		"sap/ui/model/odata/ODataModel",
		"sap/m/MessageToast"
	], function (BaseController, JSONModel, History, formatter, Filter, FilterOperator,ODataModel,MessageToast) {
		"use strict";

		return BaseController.extend("zsapui5proj07wlfullscreen.controller.Worklist", {

			formatter: formatter,
			
              onInit : function(){
              	//URL
              	var proddata = "/sap/opu/odata/iwbep/GWSAMPLE_BASIC/";
              	//Product Set Data
              	//1. Instantiation
              	var prod_odatamodel = new ODataModel(proddata);
              	var prod_jsonmodel = new JSONModel();
              	var prod_jsonmodel_combo_dyn = new JSONModel();  //for product ID's of combobox
              	var prod_jsonmodel_combo_dyn_cat = new JSONModel();  //for Category of combobox

              	sap.ui.core.BusyIndicator.show(0);  //Busy indicator
              	prod_odatamodel.read("/ProductSet",{
              		success : function(req,resp){
              	     sap.ui.core.BusyIndicator.hide();  //Busy indicator
              	     prod_jsonmodel_combo_dyn.setSizeLimit(1000);  //Product ID combo box
              	     
              	     //2. data Binding
              		 prod_jsonmodel.setData(req.results);
              		 prod_jsonmodel_combo_dyn.setData(req.results);  //Product ID combo box
              		 prod_jsonmodel_combo_dyn_cat.setData(req.results);  //Category of combo box
              		 //3. display
              		 this.getView().byId("tableproduct_table_id").setModel(prod_jsonmodel,"prod");
              		 this.getView().byId("combo_box_id_dyn").setModel(prod_jsonmodel_combo_dyn,"dyn_prod");
              		 this.getView().byId("id_combo_box_cat_dyn").setModel(prod_jsonmodel_combo_dyn_cat,"dyn_cat");
              		}.bind(this),
              		error : function(msg){
              	        sap.ui.core.BusyIndicator.hide();       //Busy indicator       			
              			MessageToast.show("Failed:1000:" + msg);
              		}
              	});
              }, //end of OnInit
              
              _order_by_price: function(){
              	//URL
              	var proddata = "/sap/opu/odata/iwbep/GWSAMPLE_BASIC/";
              	//Product Set Data
              	//1. Instantiation
              	var prod_odatamodel = new ODataModel(proddata);
              	var prod_jsonmodel = new JSONModel();
              	
              	sap.ui.core.BusyIndicator.show(0);  //Busy indicator
              	prod_odatamodel.read("/ProductSet?$orderby=Price",{
              		success : function(req,resp){
              	     sap.ui.core.BusyIndicator.hide();  //Busy indicator
              	     //2. data Binding
              		 prod_jsonmodel.setData(req.results);
              		 //3. display
              		 this.getView().byId("tableproduct_table_id").setModel(prod_jsonmodel,"prod");
              		}.bind(this),
              		error : function(msg){
              	        sap.ui.core.BusyIndicator.hide();       //Busy indicator       			
              			MessageToast.show("Failed:1001:" + msg);
              		}
              	});              	
              },//end of _order_by_price

            _refresh: function(){
             this.onInit();
            },  //end of _refresh
            
            _pricelt1: function(){
              	//URL
              	var proddata = "/sap/opu/odata/iwbep/GWSAMPLE_BASIC/";
              	//Product Set Data
              	//1. Instantiation
              	var prod_odatamodel = new ODataModel(proddata);
              	var prod_jsonmodel = new JSONModel();
              	var filter1 = new Filter("Price",FilterOperator.LT,"1");
              	
              	sap.ui.core.BusyIndicator.show(0);  //Busy indicator
              	prod_odatamodel.read("/ProductSet",{
              		filters : [filter1],
              		success : function(req,resp){
              	     sap.ui.core.BusyIndicator.hide();  //Busy indicator
              	     //2. data Binding
              		 prod_jsonmodel.setData(req.results);
              		 //3. display
              		 this.getView().byId("tableproduct_table_id").setModel(prod_jsonmodel,"prod");
              		}.bind(this),
              		error : function(msg){
              	        sap.ui.core.BusyIndicator.hide();       //Busy indicator       			
              			MessageToast.show("Failed:1001:" + msg);
              		}
              	});              	            	
            },  //end of _pricelt1
            
            _weightgt80:function(){
              	//URL
              	var proddata = "/sap/opu/odata/iwbep/GWSAMPLE_BASIC/";
              	//Product Set Data
              	//1. Instantiation
              	var prod_odatamodel = new ODataModel(proddata);
              	var prod_jsonmodel = new JSONModel();
              	var filter2 = new Filter("WeightMeasure",FilterOperator.GT,"80");
              	
              	sap.ui.core.BusyIndicator.show(0);  //Busy indicator
              	prod_odatamodel.read("/ProductSet",{
              		filters : [filter2],
              		success : function(req,resp){
              	     sap.ui.core.BusyIndicator.hide();  //Busy indicator
              	     //2. data Binding
              		 prod_jsonmodel.setData(req.results);
              		 //3. display
              		 this.getView().byId("tableproduct_table_id").setModel(prod_jsonmodel,"prod");
              		}.bind(this),
              		error : function(msg){
              	        sap.ui.core.BusyIndicator.hide();       //Busy indicator       			
              			MessageToast.show("Failed:1002:" + msg);
              		}
              	});            	
            },  //end of _weightgt80
            
            _cateqnotebooks:function(){
              	//URL
              	var proddata = "/sap/opu/odata/iwbep/GWSAMPLE_BASIC/";
              	//Product Set Data
              	//1. Instantiation
              	var prod_odatamodel = new ODataModel(proddata);
              	var prod_jsonmodel = new JSONModel();
              	var filter3 = new Filter("Category",FilterOperator.EQ,"Notebooks");
              	
              	sap.ui.core.BusyIndicator.show(0);  //Busy indicator
              	prod_odatamodel.read("/ProductSet",{
              		filters : [filter3],
              		success : function(req,resp){
              	     sap.ui.core.BusyIndicator.hide();  //Busy indicator
              	     //2. data Binding
              		 prod_jsonmodel.setData(req.results);
              		 //3. display
              		 this.getView().byId("tableproduct_table_id").setModel(prod_jsonmodel,"prod");
              		}.bind(this),
              		error : function(msg){
              	        sap.ui.core.BusyIndicator.hide();       //Busy indicator       			
              			MessageToast.show("Failed:1003:" + msg);
              		}
              	});            	
            }, //end of _cateqglue
            
            _pricebt1and7: function(){
              	//URL
              	var proddata = "/sap/opu/odata/iwbep/GWSAMPLE_BASIC/";
              	//Product Set Data
              	//1. Instantiation
              	var prod_odatamodel = new ODataModel(proddata);
              	var prod_jsonmodel = new JSONModel();
              	var filter4 = new Filter("Price",FilterOperator.BT,"1","7");
              	
              	sap.ui.core.BusyIndicator.show(0);  //Busy indicator
              	prod_odatamodel.read("/ProductSet?$orderby=Category",{
              		filters : [filter4],
              		success : function(req,resp){
              	     sap.ui.core.BusyIndicator.hide();  //Busy indicator
              	     //2. data Binding
              		 prod_jsonmodel.setData(req.results);
              		 //3. display
              		 this.getView().byId("tableproduct_table_id").setModel(prod_jsonmodel,"prod");
              		}.bind(this),
              		error : function(msg){
              	        sap.ui.core.BusyIndicator.hide();       //Busy indicator       			
              			MessageToast.show("Failed:1004:" + msg);
              		}
              	});                 	
            },  //end of _pricebt1and2
            
            _catsubmit: function(){
                // this.byId("inputcatsearch").mProperties.value;
                var catsearchname = this.byId("inputcatsearch").getValue();
                //with above, Now the 'CATSEARCHNAME' variable contains the value that we entered in the input 
                // search field-->in our case it is 'Notebooks'
                switch(catsearchname){
                	case "":
                		MessageToast.show("Enter a value to search the Category");
                		return;
                	default:
                	 var proddata = "/sap/opu/odata/iwbep/GWSAMPLE_BASIC/";
              		 //1. Instantiation
              		 var prod_odatamodel = new ODataModel(proddata);
              		 var prod_jsonmodel = new JSONModel();
              		 var filter4 = new Filter("Category",FilterOperator.Contains,catsearchname);
              		 sap.ui.core.BusyIndicator.show(0);  //Busy indicator
              		 prod_odatamodel.read("/ProductSet",{
                			filters : [filter4],
              	    		success : function(req,resp){
              	    		this.byId("inputcatsearch").setValue();
              	        	sap.ui.core.BusyIndicator.hide();  //Busy indicator
              	     //2. data Binding
              			    prod_jsonmodel.setData(req.results);
              		 //3. display
              			    this.getView().byId("tableproduct_table_id").setModel(prod_jsonmodel,"prod");
              		}.bind(this),
              			error : function(msg){
              	        	sap.ui.core.BusyIndicator.hide();       //Busy indicator       			
              				MessageToast.show("Failed:1005:" + msg);
              			}
              		});            	                
                }  //end of switch statement

               /* if (catsearchname === ""){
                	MessageToast.show("Enter a value to search");
                }
                else{
                 var proddata = "/sap/opu/odata/iwbep/GWSAMPLE_BASIC/";
              	 //1. Instantiation
              	 var prod_odatamodel = new ODataModel(proddata);
              	 var prod_jsonmodel = new JSONModel();
              	 var filter4 = new Filter("Category",FilterOperator.Contains,catsearchname);
              	 sap.ui.core.BusyIndicator.show(0);  //Busy indicator
              	 prod_odatamodel.read("/ProductSet",{
                		filters : [filter4],
              	    	success : function(req,resp){
              	    	this.byId("inputcatsearch").setValue();
              	        sap.ui.core.BusyIndicator.hide();  //Busy indicator
              	     //2. data Binding
              		 prod_jsonmodel.setData(req.results);
              		 //3. display
              		 this.getView().byId("tableproduct_table_id").setModel(prod_jsonmodel,"prod");
              		}.bind(this),
              		error : function(msg){
              	        sap.ui.core.BusyIndicator.hide();       //Busy indicator       			
              			MessageToast.show("Failed:1005:" + msg);
              		}
              	});            	                
                } //end of ELSE condition*/
            },  //end of _catsubmit
            _name_search_submit:function(){
                // this.byId("inputcatsearch").mProperties.value;
                var namesearch = this.byId("name_search_v").getValue();
                //with above, Now the 'CATSEARCHNAME' variable contains the value that we entered in the input 
                // search field-->in our case it is 'Notebooks'
                switch(namesearch){
                	case "":
                		MessageToast.show("Enter a value to search the name");
                		return;
                	default:
                	 var proddata = "/sap/opu/odata/iwbep/GWSAMPLE_BASIC/";
              		 //1. Instantiation
              		 var prod_odatamodel = new ODataModel(proddata);
              		 var prod_jsonmodel = new JSONModel();
              		 var filter5 = new Filter("Name",FilterOperator.Contains,namesearch);
              		 sap.ui.core.BusyIndicator.show(0);  //Busy indicator
              		 prod_odatamodel.read("/ProductSet",{
                			filters : [filter5],
              	    		success : function(req,resp){
              	    		this.byId("name_search_v").setValue();
              	        	sap.ui.core.BusyIndicator.hide();  //Busy indicator
              	     //2. data Binding
              			    prod_jsonmodel.setData(req.results);
              		 //3. display
              			    this.getView().byId("tableproduct_table_id").setModel(prod_jsonmodel,"prod");
              		}.bind(this),
              			error : function(msg){
              	        	sap.ui.core.BusyIndicator.hide();       //Busy indicator       			
              				MessageToast.show("Failed:1006:" + msg);
              			}
              		});            	                
                }  //end of switch statement            	
            },  //end of _name_search_submit
            
            _price_search_submit:function(){
                // this.byId("inputcatsearch").mProperties.value;
                var pricesearch = this.byId("price_search_v").getValue();
                var regex_price_e_or_E = /[a-zA-Z]/;  //for Regular Expression
                //Start of regular expression for Price search.
                var lv_flag = false;
                
                lv_flag = regex_price_e_or_E.test(pricesearch);
				 if (lv_flag === true) {
                	MessageToast.show("Enter a numeric value to search the Price");
                	return;
					} //if (lv_flag === true)
			    //End of regular expression for Price search
			    
                //with above, Now the 'CATSEARCHNAME' variable contains the value that we entered in the input 
                // search field-->in our case it is 'Notebooks'
                if (pricesearch == ""){
                		MessageToast.show("Enter a value to search the Price");                	
                }else{
                	 var proddata = "/sap/opu/odata/iwbep/GWSAMPLE_BASIC/";
              		 //1. Instantiation
              		 var prod_odatamodel = new ODataModel(proddata);
              		 var prod_jsonmodel = new JSONModel();
              		 var filter6 = new Filter("Price",FilterOperator.EQ,pricesearch);
              		 sap.ui.core.BusyIndicator.show(0);  //Busy indicator
              		 prod_odatamodel.read("/ProductSet",{
                			filters : [filter6],
              	    		success : function(req,resp){
              	    		this.byId("price_search_v").setValue();
              	        	sap.ui.core.BusyIndicator.hide();  //Busy indicator
              	     //2. data Binding
              			    prod_jsonmodel.setData(req.results);
              		 //3. display
              			    this.getView().byId("tableproduct_table_id").setModel(prod_jsonmodel,"prod");
              		}.bind(this),
              			error : function(msg){
              	        	sap.ui.core.BusyIndicator.hide();       //Busy indicator       			
              				MessageToast.show("Failed:1007:" + msg);              			}
              		});            	                                	
                }
            },  //end of _price_search_submit
            
            _combo_box_static_chng:function(oevent){
             var key = this.byId("combo_box_id_static").getSelectedKey();
        	 switch (key){
        	 	case " ":
        	 	 this._refresh();
        	 	 break;
         	    case "1":  //Order by Price
         	     this._order_by_price();
         	     break;
         	    case "2":  //Price lt $1
         	     this._pricelt1();
         	     break;
         	    case "3":  //Weight Gt 80KG
         	     this._weightgt80();
         	     break;
         	    case "4":  //Category eq to Notebooks
         	     this._cateqnotebooks();
         	     break;
         	    case "5":  //Price bet $1 and $7
         	     this._pricebt1and7();
         	     break;
               } //end of SWITCH statement
            },  //end of _combo_box_static_chng
            
            _combo_box_dyn_chng:function(oevent){
            	var dyn_value = oevent.getParameter("value");
              	//URL
              	var proddata = "/sap/opu/odata/iwbep/GWSAMPLE_BASIC/";
              	//Product Set Data
              	//1. Instantiation
              	var prod_odatamodel = new ODataModel(proddata);
              	var prod_jsonmodel = new JSONModel();
              	var filter8 = new Filter("ProductID",FilterOperator.EQ,dyn_value);
              	
              	sap.ui.core.BusyIndicator.show(0);  //Busy indicator
              	prod_odatamodel.read("/ProductSet",{
              		filters : [filter8],
              		success : function(req,resp){
              	     sap.ui.core.BusyIndicator.hide();  //Busy indicator
              	     //2. data Binding
              		 prod_jsonmodel.setData(req.results);
              		 //3. display
              		 this.getView().byId("tableproduct_table_id").setModel(prod_jsonmodel,"prod");
              		}.bind(this),
              		error : function(msg){
              	        sap.ui.core.BusyIndicator.hide();       //Busy indicator       			
              			MessageToast.show("Failed:1008:" + msg);
              		}
              	});              	            	            	
            },  //end of _combo_box_dynamic_chng
            
            _combo_box_dyn_chng_cat:function(oevent_cat){
            	var dyn_value_cat = oevent_cat.getParameter("value");
              	//URL
              	var proddata = "/sap/opu/odata/iwbep/GWSAMPLE_BASIC/";
              	//Product Set Data
              	//1. Instantiation
              	var prod_odatamodel = new ODataModel(proddata);
              	var prod_jsonmodel = new JSONModel();
              	var filter9 = new Filter("Category",FilterOperator.EQ,dyn_value_cat);
              	
              	sap.ui.core.BusyIndicator.show(0);  //Busy indicator
              	prod_odatamodel.read("/ProductSet",{
              		filters : [filter9],
              		success : function(req,resp){
              	     sap.ui.core.BusyIndicator.hide();  //Busy indicator
              	     //2. data Binding
              		 prod_jsonmodel.setData(req.results);
              		 //3. display
              		 this.getView().byId("tableproduct_table_id").setModel(prod_jsonmodel,"prod");
              		}.bind(this),
              		error : function(msg){
              	        sap.ui.core.BusyIndicator.hide();       //Busy indicator       			
              			MessageToast.show("Failed:1009:" + msg);
              		}
              	});            	
            },  //end of _combo_box_dyn_chng_cat
            
            _row_details:function(oevent){
             MessageToast.show("row clicked");
             var binding_context = oevent.getSource().getBindingContext("prod");
             var product_id = binding_context.getProperty("ProductID");
             var product_price = binding_context.getProperty("Price");
             MessageToast.show(product_id + "------" + product_price);
            },  //end of _row_details
          
            _name_upper_case:function(){
                // var name_entered = this.byId("name_livechange").getValue().toUpperCase();
                // this.byId("name_livechange").setValue(name_entered);
                this.byId("name_livechange").setValue(this.byId("name_livechange").getValue().toUpperCase());             
            }, //end of _name_upper_case
            
            _navigate_to_object_view: function(){
             this.oRouter = sap.ui.core.UIComponent.getRouterFor(this);
             this.oRouter.navTo("object",{
             	from : "worklist",
             	to   : "object"
             },true);
             MessageToast.show("You are navigating from worklist to object list");             
            },  //end of _navigate_ot_object_view
            
			/* =========================================================== */
			/* lifecycle methods                                           */
			/* =========================================================== */

			/**
			 * Called when the worklist controller is instantiated.
			 * @public
			 */
			_onInit : function () {
				var oViewModel,
					iOriginalBusyDelay,
					oTable = this.byId("table");

				// Put down worklist table's original value for busy indicator delay,
				// so it can be restored later on. Busy handling on the table is
				// taken care of by the table itself.
				iOriginalBusyDelay = oTable.getBusyIndicatorDelay();
				this._oTable = oTable;
				// keeps the search state
				this._oTableSearchState = [];

				// Model used to manipulate control states
				oViewModel = new JSONModel({
					worklistTableTitle : this.getResourceBundle().getText("worklistTableTitle"),
					saveAsTileTitle: this.getResourceBundle().getText("saveAsTileTitle", this.getResourceBundle().getText("worklistViewTitle")),
					shareOnJamTitle: this.getResourceBundle().getText("worklistTitle"),
					shareSendEmailSubject: this.getResourceBundle().getText("shareSendEmailWorklistSubject"),
					shareSendEmailMessage: this.getResourceBundle().getText("shareSendEmailWorklistMessage", [location.href]),
					tableNoDataText : this.getResourceBundle().getText("tableNoDataText"),
					tableBusyDelay : 0
				});
				this.setModel(oViewModel, "worklistView");

				// Make sure, busy indication is showing immediately so there is no
				// break after the busy indication for loading the view's meta data is
				// ended (see promise 'oWhenMetadataIsLoaded' in AppController)
				oTable.attachEventOnce("updateFinished", function(){
					// Restore original busy indicator delay for worklist's table
					oViewModel.setProperty("/tableBusyDelay", iOriginalBusyDelay);
				});
			},

			/* =========================================================== */
			/* event handlers                                              */
			/* =========================================================== */

			/**
			 * Triggered by the table's 'updateFinished' event: after new table
			 * data is available, this handler method updates the table counter.
			 * This should only happen if the update was successful, which is
			 * why this handler is attached to 'updateFinished' and not to the
			 * table's list binding's 'dataReceived' method.
			 * @param {sap.ui.base.Event} oEvent the update finished event
			 * @public
			 */
			onUpdateFinished : function (oEvent) {
				// update the worklist's object counter after the table update
				var sTitle,
					oTable = oEvent.getSource(),
					iTotalItems = oEvent.getParameter("total");
				// only update the counter if the length is final and
				// the table is not empty
				if (iTotalItems && oTable.getBinding("items").isLengthFinal()) {
					sTitle = this.getResourceBundle().getText("worklistTableTitleCount", [iTotalItems]);
				} else {
					sTitle = this.getResourceBundle().getText("worklistTableTitle");
				}
				this.getModel("worklistView").setProperty("/worklistTableTitle", sTitle);
			},

			/**
			 * Event handler when a table item gets pressed
			 * @param {sap.ui.base.Event} oEvent the table selectionChange event
			 * @public
			 */
			onPress : function (oEvent) {
				// The source is the list item that got pressed
				this._showObject(oEvent.getSource());
			},



			/**
			 * Event handler when the share in JAM button has been clicked
			 * @public
			 */
			onShareInJamPress : function () {
				var oViewModel = this.getModel("worklistView"),
					oShareDialog = sap.ui.getCore().createComponent({
						name: "sap.collaboration.components.fiori.sharing.dialog",
						settings: {
							object:{
								id: location.href,
								share: oViewModel.getProperty("/shareOnJamTitle")
							}
						}
					});
				oShareDialog.open();
			},

			onSearch : function (oEvent) {
				if (oEvent.getParameters().refreshButtonPressed) {
					// Search field's 'refresh' button has been pressed.
					// This is visible if you select any master list item.
					// In this case no new search is triggered, we only
					// refresh the list binding.
					this.onRefresh();
				} else {
					var oTableSearchState = [];
					var sQuery = oEvent.getParameter("query");

					if (sQuery && sQuery.length > 0) {
						oTableSearchState = [new Filter("Category", FilterOperator.Contains, sQuery)];
					}
					this._applySearch(oTableSearchState);
				}

			},

			/**
			 * Event handler for refresh event. Keeps filter, sort
			 * and group settings and refreshes the list binding.
			 * @public
			 */
			onRefresh : function () {
				this._oTable.getBinding("items").refresh();
			},

			/* =========================================================== */
			/* internal methods                                            */
			/* =========================================================== */

			/**
			 * Shows the selected item on the object page
			 * On phones a additional history entry is created
			 * @param {sap.m.ObjectListItem} oItem selected Item
			 * @private
			 */
			_showObject : function (oItem) {
				this.getRouter().navTo("object", {
					objectId: oItem.getBindingContext().getProperty("ProductID")
				});
			},

			/**
			 * Internal helper method to apply both filter and search state together on the list binding
			 * @param {object} oTableSearchState an array of filters for the search
			 * @private
			 */
			_applySearch: function(oTableSearchState) {
				var oViewModel = this.getModel("worklistView");
				this._oTable.getBinding("items").filter(oTableSearchState, "Application");
				// changes the noDataText of the list in case there are no filter results
				if (oTableSearchState.length !== 0) {
					oViewModel.setProperty("/tableNoDataText", this.getResourceBundle().getText("worklistNoDataWithSearchText"));
				}
			}

		});
	}
);