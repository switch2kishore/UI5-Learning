sap.ui.define([
	"sap/ui/core/mvc/Controller",
	"sap/m/MessageToast"
], function(Controller, MessageToast) {
	"use strict";

	return Controller.extend("zsapui5proj07wlfullscreen.controller.view3", {

		/**
		 * Called when a controller is instantiated and its View controls (if available) are already created.
		 * Can be used to modify the View before it is displayed, to bind event handlers and do other one-time initialization.
		 * @memberOf zsapui5proj07wlfullscreen.view.view3
		 */
			onInit: function() {
		
			},

          _go_back_to_object_list:function(){
          	debugger;  //in view3.controller
             this.oRouter = sap.ui.core.UIComponent.getRouterFor(this);            	
             this.oRouter.navTo("object",{
             	from : "view3",
             	to   : "object"
             },true);  
             MessageToast.show("You are navigating from view3 to object list");
          },
          
		   _go_back_to_work_list:function(){
             this.oRouter = sap.ui.core.UIComponent.getRouterFor(this);            	
             this.oRouter.navTo("worklist",{
             	from : "view3",
             	to   : "worklist"
             },true);  
             MessageToast.show("You are navigating from view3 to work list");	
		  },          
		/**
		 * Similar to onAfterRendering, but this hook is invoked before the controller's View is re-rendered
		 * (NOT before the first rendering! onInit() is used for that one!).
		 * @memberOf zsapui5proj07wlfullscreen.view.view3
		 */
		//	onBeforeRendering: function() {
		//
		//	},

		/**
		 * Called when the View has been rendered (so its HTML is part of the document). Post-rendering manipulations of the HTML could be done here.
		 * This hook is the same one that SAPUI5 controls get after being rendered.
		 * @memberOf zsapui5proj07wlfullscreen.view.view3
		 */
		//	onAfterRendering: function() {
		//
		//	},

		/**
		 * Called when the Controller is destroyed. Use this one to free resources and finalize activities.
		 * @memberOf zsapui5proj07wlfullscreen.view.view3
		 */
		//	onExit: function() {
		//
		//	}

	});

});