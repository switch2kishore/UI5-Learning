sap.ui.define([
	"sap/ui/core/mvc/Controller"
], function(Controller) {
	"use strict";

	return Controller.extend("zsapui5proj07wlfullscreen.controller.View3", {

		/**
		 * Called when a controller is instantiated and its View controls (if available) are already created.
		 * Can be used to modify the View before it is displayed, to bind event handlers and do other one-time initialization.
		 * @memberOf zsapui5proj07wlfullscreen.view.View3
		 */
		 onInit:function(){
		 	debugger; //in View 3
		 },
			
/*			onInit: function() {
			 debugger;  //4th debugger
				this.oRouter = sap.ui.core.UIComponent.getRouterFor(this);
				// this.oRouter.getRoute("object").attachPatternMatched(this._getting_the_data,this);	
				this.oRouter.getRoute("object").attachMatched(this._getting_the_view3,this);		     
			},  // end of onInit
			
			_getting_the_view3:function(){
				
			},  //end of _getting_the_view3
			
          _to_view3: function(){
          	debugger;  //5th debugger
          },  //end of _to_view3*/
		/**
		 * Similar to onAfterRendering, but this hook is invoked before the controller's View is re-rendered
		 * (NOT before the first rendering! onInit() is used for that one!).
		 * @memberOf zsapui5proj07wlfullscreen.view.View3
		 */
		//	onBeforeRendering: function() {
		//
		//	},

		/**
		 * Called when the View has been rendered (so its HTML is part of the document). Post-rendering manipulations of the HTML could be done here.
		 * This hook is the same one that SAPUI5 controls get after being rendered.
		 * @memberOf zsapui5proj07wlfullscreen.view.View3
		 */
		//	onAfterRendering: function() {
		//
		//	},

		/**
		 * Called when the Controller is destroyed. Use this one to free resources and finalize activities.
		 * @memberOf zsapui5proj07wlfullscreen.view.View3
		 */
		//	onExit: function() {
		//
		//	}

	});

});