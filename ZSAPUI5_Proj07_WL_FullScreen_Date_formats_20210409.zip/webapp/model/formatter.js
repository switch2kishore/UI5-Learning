sap.ui.define([
	"sap/ui/core/format/DateFormat"], 
	function(DateFormat) {
	"use strict";

	return {
		width_to_six_decimals: function(lv_width) {
			if (lv_width === "0.000") {
				return ("No Data");
			} else {
				return parseFloat(lv_width).toFixed(6);
			}
		},
		discount_price: function(lv_price) {
			if (lv_price >= 30 && lv_price <= 50) {
				return parseFloat(lv_price - 10).toFixed(3);
			}
			if (lv_price >= 50 && lv_price <= 100) {
				return parseFloat(lv_price - 20).toFixed(3);
			}
			if (lv_price > 100) {
				return parseFloat(lv_price - 30).toFixed(3);
			}
			return parseFloat(lv_price).toFixed(3);
		},
		price_color: function(lv_price_color) {
			if (lv_price_color >= 30 && lv_price_color <= 50) {
				return 'Success';
			}
			if (lv_price_color >= 50 && lv_price_color <= 100) {
				return 'Warning';
			}
			if (lv_price_color > 100) {
				return 'Error';
			}
		},
		date1: function(created_date) {
			if (!created_date || created_date === undefined) {
				return "";
			}
			//return new Date(created_date).toDateString();
			return new Date(created_date).toLocaleDateString();
		},

		date2: function(changed_date) {
			if (!changed_date || changed_date === undefined) {
				return "";
			}
			return new Date(changed_date).toDateString();
		},

        dateTimeDisplay: function(d3){
        	if (!d3 || d3 === undefined){
        		return "";
        	}
        	var oDateFormat = DateFormat.getDateInstance({
        		scale:"medium",
        		pattern:"dd-MM-yyyy"
        	});
        	var final_date = oDateFormat.format(new Date(d3));
        	return final_date;
        },
		/**
		 * Rounds the number unit value to 2 digits
		 * @public
		 * @param {string} sValue the number string to be rounded
		 * @returns {string} sValue with 2 digits rounded
		 */
		numberUnit: function(sValue) {
			if (!sValue) {
				return "";
			}
			return parseFloat(sValue).toFixed(2);
		}

	};

});